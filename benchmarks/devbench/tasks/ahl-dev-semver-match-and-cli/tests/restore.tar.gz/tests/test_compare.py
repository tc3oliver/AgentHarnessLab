import warnings

import pytest

import semver
from semver import Version, compare


def test_should_compare_long_numeric_prerelease():
    value = "0.0.0-" + "1" * 5000
    assert Version.is_valid(value)
    version = Version.parse(value)
    assert version.compare(value) == 0
    assert compare(value, "0.0.0-2") == 1
    assert compare("0.0.0-2", value) == -1


@pytest.mark.parametrize(
    "lower,higher",
    [
        pytest.param("9" * 4999, "1" + "0" * 4999, id="digit-count"),
        pytest.param(
            "1" + "0" * 4998 + "1",
            "1" + "0" * 4998 + "2",
            id="equal-length",
        ),
        pytest.param("1" * 5000, "alpha", id="numeric-before-text"),
        pytest.param("alpha." + "1" * 5000, "alpha." + "1" * 5000 + ".1", id="prefix"),
    ],
)
def test_should_order_long_numeric_prereleases(lower, higher):
    low = Version.parse("0.0.0-" + lower)
    high = Version.parse("0.0.0-" + higher)
    assert low.compare(high) == -1
    assert high.compare(low) == 1
    assert sorted([high, low]) == [low, high]


def test_should_ignore_build_and_preserve_release_order_with_long_prerelease():
    version = Version.parse("0.0.0-" + "1" * 5000)
    assert version == version.replace(build="other")
    assert version < Version(0, 0, 0)


@pytest.mark.parametrize(
    "left,right,expected",
    [
        ("0001", "1", 0),
        ("000", "0", 0),
        ("02", "10", -1),
        ("01.2", "1.2", 0),
        ("2a", "10a", 1),
        ("01a", "1a", -1),
        ("-1", "0", 1),
        ("", None, 0),
        ("\u0661\u0662", "12", 0),
        ("\uff11\uff12", "13", -1),
        ("1\u0662", "12", 0),
        ("\u0660\u0660\u0661", "1", 0),
    ],
)
def test_should_preserve_constructor_prerelease_comparison(left, right, expected):
    first = Version(0, 0, 0, prerelease=left)
    second = Version(0, 0, 0, prerelease=right)
    assert first.compare(second) == expected
    assert second.compare(first) == -expected
    assert first.prerelease == left
    assert second.prerelease == right


@pytest.mark.parametrize("prerelease", ["01", "01.2", "\u0661\u0662", "\uff11\uff12"])
def test_should_reject_noncanonical_prerelease_when_parsing(prerelease):
    with pytest.raises(ValueError):
        Version.parse("0.0.0-" + prerelease)


@pytest.mark.parametrize(
    "left,right,expected",
    [("\u00b2", "2", 1), ("a.\u00b2", "b.0", -1), ("a.0", "b.\u00b2", -1)],
)
def test_should_compare_superscript_digit_as_alphanumeric(left, right, expected):
    # "\u00b2" is not a decimal digit (int("\u00b2") raises ValueError), so it is an
    # alphanumeric identifier: numeric identifiers always precede it.
    assert (
        Version(0, 0, 0, prerelease=left).compare(
            Version(0, 0, 0, prerelease=right)
        )
        == expected
    )


def test_should_compare_core_before_invalid_prerelease():
    assert Version(0, 0, 0, prerelease="\u00b2") < Version(1, 0, 0, prerelease="\u00b2")


@pytest.mark.parametrize(
    "left,right",
    [
        ("1.0.0", "2.0.0"),
        ("1.0.0-alpha", "1.0.0-alpha.1"),
        ("1.0.0-alpha.1", "1.0.0-alpha.beta"),
        ("1.0.0-alpha.beta", "1.0.0-beta"),
        ("1.0.0-beta", "1.0.0-beta.2"),
        ("1.0.0-beta.2", "1.0.0-beta.11"),
        ("1.0.0-beta.11", "1.0.0-rc.1"),
        ("1.0.0-rc.1", "1.0.0"),
    ],
)
def test_should_get_less(left, right):
    assert compare(left, right) == -1


@pytest.mark.parametrize(
    "left,right",
    [
        ("2.0.0", "1.0.0"),
        ("1.0.0-alpha.1", "1.0.0-alpha"),
        ("1.0.0-alpha.beta", "1.0.0-alpha.1"),
        ("1.0.0-beta", "1.0.0-alpha.beta"),
        ("1.0.0-beta.2", "1.0.0-beta"),
        ("1.0.0-beta.11", "1.0.0-beta.2"),
        ("1.0.0-rc.1", "1.0.0-beta.11"),
        ("1.0.0", "1.0.0-rc.1"),
    ],
)
def test_should_get_greater(left, right):
    assert compare(left, right) == 1


@pytest.mark.parametrize(
    "left,right", [("foo", "bar"), ("1.0", "1.0.0"), ("1.x", "1.0.0")]
)
def test_should_raise_value_error_for_invalid_value(left, right):
    with pytest.raises(ValueError):
        compare(left, right)


def test_should_follow_specification_comparison():
    """
    produce comparison chain:
    1.0.0-alpha < 1.0.0-alpha.1 < 1.0.0-beta.2 < 1.0.0-beta.11
    < 1.0.0-rc.1 < 1.0.0-rc.1+build.1 < 1.0.0 < 1.0.0+0.3.7 < 1.3.7+build
    < 1.3.7+build.2.b8f12d7 < 1.3.7+build.11.e0f985a
    and in backward too.
    """
    chain = [
        "1.0.0-alpha",
        "1.0.0-alpha.1",
        "1.0.0-beta.2",
        "1.0.0-beta.11",
        "1.0.0-rc.1",
        "1.0.0",
        "1.3.7+build",
    ]
    versions = zip(chain[:-1], chain[1:])
    for low_version, high_version in versions:
        assert (
            compare(low_version, high_version) == -1
        ), "%s should be lesser than %s" % (low_version, high_version)
        assert (
            compare(high_version, low_version) == 1
        ), "%s should be higher than %s" % (high_version, low_version)


@pytest.mark.parametrize("left,right", [("1.0.0-beta.2", "1.0.0-beta.11")])
def test_should_compare_rc_builds(left, right):
    assert compare(left, right) == -1


@pytest.mark.parametrize(
    "left,right", [("1.0.0-rc.1", "1.0.0"), ("1.0.0-rc.1+build.1", "1.0.0")]
)
def test_should_compare_release_candidate_with_release(left, right):
    assert compare(left, right) == -1


@pytest.mark.parametrize(
    "left,right",
    [
        ("2.0.0", "2.0.0"),
        ("1.1.9-rc.1", "1.1.9-rc.1"),
        ("1.1.9+build.1", "1.1.9+build.1"),
        ("1.1.9-rc.1+build.1", "1.1.9-rc.1+build.1"),
    ],
)
def test_should_say_equal_versions_are_equal(left, right):
    assert compare(left, right) == 0


@pytest.mark.parametrize(
    "left,right,expected",
    [("1.1.9-rc.1", "1.1.9-rc.1+build.1", 0), ("1.1.9-rc.1", "1.1.9+build.1", -1)],
)
def test_should_compare_versions_with_build_and_release(left, right, expected):
    assert compare(left, right) == expected


@pytest.mark.parametrize(
    "left,right,expected",
    [
        ("1.0.0+build.1", "1.0.0", 0),
        ("1.0.0-alpha.1+build.1", "1.0.0-alpha.1", 0),
        ("1.0.0+build.1", "1.0.0-alpha.1", 1),
        ("1.0.0+build.1", "1.0.0-alpha.1+build.1", 1),
    ],
)
def test_should_ignore_builds_on_compare(left, right, expected):
    assert compare(left, right) == expected


def test_should_get_more_rc1():
    assert compare("1.0.0-rc1", "1.0.0-rc0") == 1


def test_should_compare_prerelease_with_numbers_and_letters():
    v1 = Version(major=1, minor=9, patch=1, prerelease="1unms", build=None)
    v2 = Version(major=1, minor=9, patch=1, prerelease=None, build="1asd")
    assert v1 < v2
    assert compare("1.9.1-1unms", "1.9.1+1") == -1


def test_should_compare_version_info_objects():
    v1 = Version(major=0, minor=10, patch=4)
    v2 = Version(major=0, minor=10, patch=4, prerelease="beta.1", build=None)

    # use `not` to enforce using comparision operators
    assert v1 != v2
    assert v1 > v2
    assert v1 >= v2
    assert not (v1 < v2)
    assert not (v1 <= v2)
    assert not (v1 == v2)

    v3 = Version(major=0, minor=10, patch=4)

    assert not (v1 != v3)
    assert not (v1 > v3)
    assert v1 >= v3
    assert not (v1 < v3)
    assert v1 <= v3
    assert v1 == v3

    v4 = Version(major=0, minor=10, patch=5)
    assert v1 != v4
    assert not (v1 > v4)
    assert not (v1 >= v4)
    assert v1 < v4
    assert v1 <= v4
    assert not (v1 == v4)


def test_should_compare_version_dictionaries():
    v1 = Version(major=0, minor=10, patch=4)
    v2 = dict(major=0, minor=10, patch=4, prerelease="beta.1", build=None)

    assert v1 != v2
    assert v1 > v2
    assert v1 >= v2
    assert not (v1 < v2)
    assert not (v1 <= v2)
    assert not (v1 == v2)

    v3 = dict(major=0, minor=10, patch=4)

    assert not (v1 != v3)
    assert not (v1 > v3)
    assert v1 >= v3
    assert not (v1 < v3)
    assert v1 <= v3
    assert v1 == v3

    v4 = dict(major=0, minor=10, patch=5)
    assert v1 != v4
    assert not (v1 > v4)
    assert not (v1 >= v4)
    assert v1 < v4
    assert v1 <= v4
    assert not (v1 == v4)


@pytest.mark.parametrize(
    "t",  # fmt: off
    (
        (1, 0, 0),
        (1, 0),
        (1,),
        (1, 0, 0, "pre.2"),
        (1, 0, 0, "pre.2", "build.4"),
    ),  # fmt: on
)
def test_should_compare_version_tuples(t):
    v0 = Version(major=0, minor=4, patch=5, prerelease="pre.2", build="build.4")
    v1 = Version(major=3, minor=4, patch=5, prerelease="pre.2", build="build.4")

    assert v0 < t
    assert v0 <= t
    with pytest.warns(DeprecationWarning):
        assert v0 != t
    with pytest.warns(DeprecationWarning):
        assert not v0 == t
    assert v1 > t
    assert v1 >= t
    # Symmetric
    assert t > v0
    assert t >= v0
    assert t < v1
    assert t <= v1
    with pytest.warns(DeprecationWarning):
        assert t != v0
    with pytest.warns(DeprecationWarning):
        assert not t == v0


@pytest.mark.parametrize("other", ["1.0.0", (1, 0, 0)])
def test_should_warn_when_testing_equality_with_strings_or_tuples(other):
    version = Version.parse("1.0.0")

    with pytest.warns(DeprecationWarning, match="Equality comparisons"):
        assert version == other
    with pytest.warns(DeprecationWarning, match="Equality comparisons"):
        assert not (version != other)

    assert isinstance(hash(version), int)


def test_should_filter_only_cross_type_equality_deprecation_warnings():
    version = Version.parse("1.0.0")

    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always", DeprecationWarning)
        warnings.filterwarnings(
            "ignore",
            message=r"Equality comparisons between Version and strings, tuples or lists.*",
            category=DeprecationWarning,
        )

        for other in ("1.0.0", b"1.0.0", (1, 0, 0), [1, 0, 0]):
            assert version == other
            assert (version != other) is False

        warnings.warn("unrelated deprecation", DeprecationWarning)

    assert len(caught) == 1
    assert str(caught[0].message) == "unrelated deprecation"


@pytest.mark.parametrize(
    "lst",  # fmt: off
    (
        [1, 0, 0],
        [1, 0],
        [1],
        [1, 0, 0, "pre.2"],
        [1, 0, 0, "pre.2", "build.4"],
    ),  # fmt: on
)
def test_should_compare_version_list(lst):
    v0 = Version(major=0, minor=4, patch=5, prerelease="pre.2", build="build.4")
    v1 = Version(major=3, minor=4, patch=5, prerelease="pre.2", build="build.4")

    assert v0 < lst
    assert v0 <= lst
    assert v0 != lst
    assert not v0 == lst
    assert v1 > lst
    assert v1 >= lst
    # Symmetric
    assert lst > v0
    assert lst >= v0
    assert lst < v1
    assert lst <= v1
    assert lst != v0
    assert not lst == v0


@pytest.mark.parametrize(
    "s",  # fmt: off
    (
        "1.0.0",
        # "1.0",
        # "1",
        "1.0.0-pre.2",
        "1.0.0-pre.2+build.4",
    ),  # fmt: on
)
def test_should_compare_version_string(s):
    v0 = Version(major=0, minor=4, patch=5, prerelease="pre.2", build="build.4")
    v1 = Version(major=3, minor=4, patch=5, prerelease="pre.2", build="build.4")

    assert v0 < s
    assert v0 <= s
    with pytest.warns(DeprecationWarning):
        assert v0 != s
    with pytest.warns(DeprecationWarning):
        assert not v0 == s
    assert v1 > s
    assert v1 >= s
    # Symmetric
    assert s > v0
    assert s >= v0
    assert s < v1
    assert s <= v1
    with pytest.warns(DeprecationWarning):
        assert s != v0
    with pytest.warns(DeprecationWarning):
        assert not s == v0


@pytest.mark.parametrize("s", ("1", "1.0", "1.0.x"))
def test_should_not_allow_to_compare_invalid_versionstring(s):
    v = Version(major=3, minor=4, patch=5, prerelease="pre.2", build="build.4")
    with pytest.raises(ValueError):
        v < s
    with pytest.raises(ValueError):
        s > v


def test_should_not_allow_to_compare_version_with_int():
    v1 = Version(major=3, minor=4, patch=5, prerelease="pre.2", build="build.4")
    with pytest.raises(TypeError):
        v1 > 1
    with pytest.raises(TypeError):
        1 > v1
    with pytest.raises(TypeError):
        semver.compare(1)


def test_should_compare_prerelease_and_build_with_numbers():
    assert Version(major=1, minor=9, patch=1, prerelease=1, build=1) < Version(
        major=1, minor=9, patch=1, prerelease=2, build=1
    )
    assert Version(1, 9, 1, 1, 1) < Version(1, 9, 1, 2, 1)
    assert Version("2") < Version(10)
    assert Version("2") < Version("10")

def test_direct_compare_with_collections():
    v1 = Version(1, 0, 0)
    assert v1.compare((1, 0, 0)) == 0
    assert v1.compare([1, 0, 0]) == 0
    assert v1.compare({"major": 1, "minor": 0, "patch": 0}) == 0

@pytest.mark.parametrize(
    "other",
    (
        1,
        1.0,
        1.23,
        1 + 5j,
    ),
    ids=[
        "int",
        "float",
        "float_with_decimal",
        "complex",
    ],
)
def test_direct_compare_with_invalid_type(other):
    with pytest.raises(TypeError):
        Version(1, 0, 0).compare(other)
